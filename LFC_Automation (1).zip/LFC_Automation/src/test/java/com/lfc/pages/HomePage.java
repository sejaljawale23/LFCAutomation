package com.lfc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.lfc.utils.BaseClass;

public class HomePage extends BaseClass {

// ==================Home page locators=======================	

	@FindBy(xpath = "//a[@title='Women']")
	private WebElement womenNavigationMenu;

	@FindBy(xpath = "(//a[@title='T-shirts'])[1]")
	private WebElement tshitsSubMenu;

//=========================================================================	

	public HomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void mouseHoverOnWomenNavigationBar() throws InterruptedException {
		Thread.sleep(2000);
		Actions action = new Actions(driver);
		action.moveToElement(womenNavigationMenu).perform();
	}

	public void clickOnTshirtSubMenu() {
		tshitsSubMenu.click();
	}

}
