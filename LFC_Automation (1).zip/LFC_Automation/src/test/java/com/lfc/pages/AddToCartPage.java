package com.lfc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.lfc.utils.BaseClass;

public class AddToCartPage extends BaseClass {

// ==================Add to Cart page locators=======================	

	@FindBy(xpath = "//button[@type='submit']/span[contains(text(),'Add to cart')]")
	private WebElement addToCartButton;

	@FindBy(xpath = "//a[@title='Proceed to checkout']")
	private WebElement proceedToCheckoutButton;
	
	@FindBy(xpath = "//p[@class='cart_navigation clearfix']//a[@title='Proceed to checkout']")
	private WebElement proceedToCheckoutButtonAtShoppingCartSummary;
	
	@FindBy(xpath = "//button[@name='processAddress']")
	private WebElement proceedToCheckoutButtonAtShoppingCartAddress;
	
	@FindBy(xpath = "//div[@class='checker']/span/input[@type='checkbox']")
	private WebElement termsAndConditionCheckbox;
	
	@FindBy(xpath = "//button[@name='processCarrier']")
	private WebElement proceedToCheckoutButtonAtShoppingCartShipping;
	
	@FindBy(xpath = "//a[@class='bankwire']")
	private WebElement bankWirePaymentButton;

	@FindBy(xpath = "//button[@type='submit']/span[contains(text(),'I confirm my order')]")
	private WebElement confirmOrderButton;

	@FindBy(xpath = "//p[@class='cheque-indent']/strong[contains(text(),'Your order on My Store is complete.')]")
	private WebElement orderConfirmationMessage;
	
	
	
//=========================================================================	

	public AddToCartPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	
	public void clickOnAddToCartButton()
	{
		addToCartButton.click();
	}
	
	public void clickOnProceedToCheckoutButton() throws InterruptedException {
		proceedToCheckoutButton.click();
	}

	
	public void clickOnProceedToCheckoutButtonAtShoppingCartSummaryButton() throws InterruptedException {
		proceedToCheckoutButtonAtShoppingCartSummary.click();
	}
	
	
	public void clickOnProceedToCheckoutButtonAtShoppingCartAddressButton() throws InterruptedException {
		proceedToCheckoutButtonAtShoppingCartAddress.click();
	}
	
	public void checkTermsAndConditionCheckbox() throws InterruptedException {
		termsAndConditionCheckbox.click();
	}
	
	
	public void clickOnProceedToCheckoutButtonAtShoppingCartShippingButton() throws InterruptedException {
		proceedToCheckoutButtonAtShoppingCartShipping.click();
	}
	
	public void clickOnBankWirePaymentButton() throws InterruptedException {
		bankWirePaymentButton.click();
	}
	
	
	public void clickOnConfirmOrderButton() throws InterruptedException {
		confirmOrderButton.click();
	}
	
	
	public String getOrderConfirmationMessage()
	{
		return orderConfirmationMessage.getText();
	}
	
}
