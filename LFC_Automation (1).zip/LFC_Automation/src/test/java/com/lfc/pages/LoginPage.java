package com.lfc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.lfc.utils.BaseClass;

public class LoginPage extends BaseClass {

// ==================Login page locators=======================

	@FindBy(className = "login")
	private WebElement singInLink;

	@FindBy(id = "email")
	private WebElement emailAddress;

	@FindBy(name = "passwd")
	private WebElement password;

	@FindBy(xpath = "//button[@type='submit' and @name='SubmitLogin']")
	private WebElement LoginButton;
	
	@FindBy(id = "email_create")
	private WebElement createAccountEmailAddress;

	@FindBy(name = "SubmitCreate")
	private WebElement createAccountButton;

	@FindBy(id = "create_account_error")
	private WebElement createAccountValidationMsg;

	@FindBy(className = "logout")
	private WebElement logout;
	
//=========================================================================	
	

	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void clickOnSignInLink() {
		singInLink.click();
	}

	public void enterEmailAddress(String email) {
		emailAddress.clear();
		emailAddress.sendKeys(email);
	}

	public void enterPassword(String pass) {
		password.clear();
		password.sendKeys(pass);
	}

	public void clickOnLoginButton() {
		LoginButton.click();
	}

	public void loginIntoApplication(String email, String pass) {
		clickOnSignInLink();
		enterEmailAddress(email);
		enterPassword(pass);
		clickOnLoginButton();
	}
	
	public boolean verifySignOutisDisplayed()
	{
		return logout.isDisplayed();
	}
	

	public void enterCreateAccountEmail(String createEmailAddress) {
		createAccountEmailAddress.clear();
		createAccountEmailAddress.sendKeys(createEmailAddress);
	}

	public void clickOnCreateAccountButton() {
		createAccountButton.click();
	}

	public String getValidationMessage() throws InterruptedException {
		Thread.sleep(3000);
		return createAccountValidationMsg.getText();

	}

	public void logoutFromApplication() {
		logout.click();

	}

}
