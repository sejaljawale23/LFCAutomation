package com.lfc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.lfc.utils.BaseClass;

public class PLPPage extends BaseClass {
	
// ==================PLP page locators=======================	

		@FindBy(xpath = "//a[@title='Faded Short Sleeve T-shirts' and @class='product-name']")
		private WebElement fadedShortTshirtLink;


//=========================================================================	

		public PLPPage(WebDriver driver) {
			PageFactory.initElements(driver, this);
		}

		public void clickOnFadedShortTshirtLink() throws InterruptedException {
			fadedShortTshirtLink.click();
		}

		

	}
