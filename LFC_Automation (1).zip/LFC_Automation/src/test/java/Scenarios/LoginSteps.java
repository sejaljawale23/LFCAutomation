package Scenarios;

import static org.testng.Assert.assertTrue;
import com.lfc.pages.LoginPage;
import com.lfc.utils.BaseClass;
import com.lfc.utils.Log;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps extends BaseClass {

	LoginPage loginPage = new LoginPage(driver);
	Log log= new Log();

	@Given("^user is on login screen$")
	public void UserOnLoginScreen() throws Throwable {
		loginPage.clickOnSignInLink();
		Log.info("Clicking on signin link");
		
	}

	@When("^enter user name \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void EnterValidCredential(String username, String password) throws Throwable {

		loginPage.loginIntoApplication(username, password);
		Log.info("Login into application");

	}

	@Then("^verify that user logged into application$")
	public void VerifyUserLoggedIn() throws Throwable {

		  boolean signOutLink = loginPage.verifySignOutisDisplayed();
		  assertTrue(signOutLink, "Sign Out link should be displayed");
		  Log.info("Verify that signout link is displayed");
		 
	}

	@And("^logout from the application$")
	public void logoutFromApplication() throws Throwable {

		 loginPage.logoutFromApplication(); 
		 Log.info("Logout from the application");
	}

}
