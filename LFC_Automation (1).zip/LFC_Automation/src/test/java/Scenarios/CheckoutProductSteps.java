package Scenarios;

import static org.testng.Assert.assertTrue;

import com.lfc.pages.AddToCartPage;
import com.lfc.pages.HomePage;
import com.lfc.pages.LoginPage;
import com.lfc.pages.PLPPage;
import com.lfc.utils.BaseClass;
import com.lfc.utils.PropertyReader;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CheckoutProductSteps extends BaseClass {

	LoginPage loginPage = new LoginPage(driver);
	HomePage homePage= new HomePage(driver);
	PLPPage plpPage= new PLPPage(driver);
	AddToCartPage addToCartPage= new AddToCartPage(driver);
	public PropertyReader propertyReader = new PropertyReader();

	
	@Given("^user login into application$")
	public void userOnLoginScreen() throws Throwable {
		loginPage.clickOnSignInLink();
		String email= propertyReader.readApplicationFile("EmailAddress");
		String password= propertyReader.readApplicationFile("Password");
		loginPage.loginIntoApplication(email, password);
	}

	@When("^select the product$")
	public void selectTheProduct() throws Throwable {

		homePage.mouseHoverOnWomenNavigationBar();
		homePage.clickOnTshirtSubMenu();
		plpPage.clickOnFadedShortTshirtLink();
		

	}

	@And("^checkout the product$")
	public void checkoutProduct() throws Throwable {
		addToCartPage.clickOnAddToCartButton();
		addToCartPage.clickOnProceedToCheckoutButton();
		addToCartPage.clickOnProceedToCheckoutButtonAtShoppingCartSummaryButton();
		addToCartPage.clickOnProceedToCheckoutButtonAtShoppingCartAddressButton();
		addToCartPage.checkTermsAndConditionCheckbox();
		addToCartPage.clickOnProceedToCheckoutButtonAtShoppingCartShippingButton();
		addToCartPage.clickOnBankWirePaymentButton();
	}

	@Then("^verify the payment confirmation$")
	public void verifyPaymentConfirmation() throws Throwable {

		addToCartPage.clickOnConfirmOrderButton();
		assertTrue(addToCartPage.getOrderConfirmationMessage().contains("Your order on My Store is complete"));

	}

}
